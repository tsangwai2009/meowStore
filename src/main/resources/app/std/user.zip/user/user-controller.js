'use strict';
(function()
{

	var app = angular.module('std.app');
	app.controller('UserController', ['$scope', 'userService', UserController]);

	function UserController($scope, userService)
	{
		$scope.status= null;
		$scope.submit = function()
		{
			if(!$scope.username || !$scope.password) {
		        $scope.message = "Empty username or password";
		        return;
		    }
			userService.findByUser($scope.username,$scope.password).then(function(result)
			{
				if(!result.data){
					$scope.message = "Wrong username or password";
					return;
				}
				else{
					$scope.message = "Welcome " + result.data["username"];
					$scope.status= "logined";
					
				}
			});
		};
	}                                     
})();
